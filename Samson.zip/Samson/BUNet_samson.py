#coding=utf-8

#  major Environment
# tensorflow                1.13.1 
# scipy                     1.5.2 
# numpy                     1.19.2
# opencv-python             4.2.0.34 
# Pillow                    8.4.0 
# scikit-image              0.17.2 
# keras-base                2.2.4 
# matplotlib                2.2.2 
# anaconda                  5.2.0   






import tensorflow as tf

import scipy.io as sio
import numpy as np  
from PIL import Image
import os


from skimage import io
from skimage.segmentation import slic
from skimage.util import img_as_float
from skimage.segmentation import mark_boundaries
from sklearn.cluster import KMeans
from sklearn import metrics

import keras
from keras.models import Model
from keras.layers import Input
from keras import backend as K
from keras.layers import BatchNormalization
from keras.layers import Conv2D,Dense,Concatenate,Add,Activation
from keras.engine.topology import get_source_inputs
from keras.utils.np_utils import to_categorical  
from keras.preprocessing.image import img_to_array  
from keras.callbacks import ModelCheckpoint  
from sklearn.preprocessing import LabelEncoder  
from keras.layers.merge import concatenate 
from keras.optimizers import Adam,SGD,RMSprop
from keras.callbacks import LearningRateScheduler,ReduceLROnPlateau


import matplotlib
from torch import dtype, float32, int32
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import argparse


import cv2
import random
from tqdm import tqdm  
import math
from math import pow,floor
from keras.utils import plot_model
from contextlib import redirect_stdout

import time


toal_w=95
toal_h=95
band=156
end_num=3
selectnum=60
patch=20


def dealData(img_w,img_h,stride): 
    
    
    samson = (((sio.loadmat('GroundTruth/samson_1.mat')['V']).transpose((1, 0))).astype(np.float64))
    samson=np.clip(samson,0.0,1.0)
    samson=np.reshape(samson,(toal_w,toal_h,band),order='C')
    sio.savemat('samson_3d.mat', {'samson':samson})
   
    im = Image.new("RGB", (toal_w, toal_h)) 
    for x in range(toal_w):
        for y in range(toal_h):
            im.putpixel((x, y), (int(samson[x][y][87]*255),int(samson[x][y][40]*255), int(samson[x][y][22]*255)))
        im.save('samson.png')
    
    ori_path='ori_data'+str(img_w)+'-'+str(img_h)+'-'+str(stride)+'/'  
    if not os.path.exists(ori_path):
        os.makedirs(ori_path)
    now_w=img_w
    now_h=img_h
    num=0

    while True:

        flag=0
        if(now_w< toal_w and now_h<toal_h):
            flag=1
        if(now_w>=toal_w and now_h<toal_h):
            flag=2
            now_w=toal_w
        if(now_w<toal_w and now_h>=toal_h):
            flag=3
            now_h=toal_h
        if(now_w>=toal_w and now_h>=toal_h):
            flag=4
            now_w=toal_w
            now_h=toal_h
        
        ori_data=samson[(now_h-img_h):(now_h),(now_w-img_w):(now_w),:]
        sio.savemat(ori_path+str(num)+'.mat', {'data':ori_data})   
        num+=1
        if flag==1 or flag==3:
            now_w+=stride
        if flag==2:
            now_w=img_w
            now_h+=stride
        if flag==4:
            break
    return num
    
def Slic(patch): 

  
    image = io.imread("samson.png")
    
    for numSegments in (patch,):
       
        segments = slic(img_as_float(image),n_segments=numSegments)
        path='superpixel/'+str(patch)+'/'
        if not os.path.exists(path):
            os.makedirs(path)

        for (i,segval) in enumerate(np.unique(segments)):
            mask=np.zeros(image.shape[:2],dtype='uint8')
            mask[segments==segval]=255
            superpixel=Image.fromarray(mask)
            superpixel.save(path+str(i)+'.png')
        
        out=mark_boundaries(image, segments)
        im = Image.new("RGB", (toal_w, toal_h))  
        for x in range(toal_w):
            for y in range(toal_h):
                im.putpixel((x, y), (int(out[x][y][0]*255),int(out[x][y][1]*255),int(out[x][y][2])*255))
        im=im.transpose(Image.FLIP_LEFT_RIGHT)
        im=im.rotate(90)
        im.save('samson'+str(numSegments)+'.png')
   

   
    path1='superpixel_mat/'+str(patch)+'/'
    if not os.path.exists(path1):
         os.makedirs(path1)
    block=i+1
    data=sio.loadmat('GroundTruth/samson_1.mat')['V']  
  
    for i in range(block):
         culter_data=[]
         image = io.imread(path+str(i)+'.png')
         image=np.array(image)
         for x in range((image.shape)[0]):
             for y in range((image.shape)[1]):
                 if(image[x][y]==255):
                     temp=[]
                     for j in range(band):
                         temp.append(data[j][x*toal_w+y])
                     culter_data.append(temp)

         sio.savemat(path1+str(i)+'.mat', {'data':culter_data})                   
  
    med=[]
    for i in range(block):
        Data=sio.loadmat(path1+str(i)+'.mat')
        data=Data['data']
        print(data.shape)
        km_cluster=KMeans(n_clusters=1,max_iter=100,n_init=10,init='k-means++',n_jobs=1)
        km_cluster.fit(data)
        center=km_cluster.cluster_centers_
        #temp=np.median(data,axis=0)
        #temp=np.amax(data,axis=0)
        #temp=np.percentile(data,70,axis=0)
        med.append(center[0,:])
    sio.savemat(path1+'mean_superpixel.mat', {'mean_superpixel':med})  

    data=(((sio.loadmat(path1+'mean_superpixel.mat')['mean_superpixel'])).astype(np.float32))
    km=KMeans(n_clusters=end_num,max_iter=100,n_init=10,init='k-means++',n_jobs=1) 
    km.fit(data)
    label_pred=km.labels_
    center=km.cluster_centers_
    print(center.shape)
    sio.savemat(path1+'kmeans_center.mat', {'center':center}) 
   
    all_distance= km.transform(data)   
    print(all_distance.shape)
    sio.savemat(path1+'all_distance.mat', {'all_distance':all_distance}) 
    v_temp_endmember=[]
    for i in range(end_num):
        v_temp_endmember.append([])
    for i  in range(all_distance.shape[0]):
        min=9999
        for j in range(all_distance.shape[1]):
            if all_distance[i][j]<min:
                min=all_distance[i][j]
                index=j
        v_temp_endmember[index].append(data[i,:])
    
    sio.savemat(path1+'v_temp_endmember.mat', {'v_temp_endmember':v_temp_endmember}) 

    v_endmember=[]
    for i in range(end_num):
        temp=np.array(v_temp_endmember[i])
        for  j in range(2):
            v_endmember.append(temp[j])
    sio.savemat(path1+'v_endmember.mat', {'v_endmember':v_endmember}) 

    return 0
  
def select_band(patch,selectnum): 
    path='superpixel_mat/'+str(patch)+'/'
    if not os.path.exists(path):
         os.makedirs(path)
    all_distance=sio.loadmat(path+'all_distance.mat')['all_distance']
    label=np.zeros((all_distance.shape[0]),dtype=int)
    for i in range(all_distance.shape[0]):
        min=9999
        for j in range(all_distance.shape[1]):
            if all_distance[i][j]<min:
                min=all_distance[i][j]
                label[i]=j+1
        #print(label[i])

    mean_superpixel=sio.loadmat(path+'mean_superpixel.mat')['mean_superpixel']
    
    avg_std=np.zeros((end_num,band,2),dtype=float)
    for i in range(end_num):
        temp=[]
        for j in range(label.shape[0]):
            if label[j]==i+1:
                temp.append(mean_superpixel[j])
        temp=np.array(temp)
        #print(temp.shape)
        for j in range(band):
            avg_std[i,j,0]=np.mean(temp[:,j])
            avg_std[i,j,1]=np.var(temp[:,j])
    d=np.zeros((int(end_num*(end_num-1)/2),band),dtype=float)
    num=0

    for i in range(end_num):
        for j in range(i+1,end_num):       
            for t in range(band):
                d[num,t]=(((avg_std[i,t,0]-avg_std[j,t,0])**2)**0.5)/(avg_std[i,t,0]+avg_std[j,t,0])
            num=num+1
    print(d.shape)
    grade=np.zeros((band),dtype=float)

    for i in range(band):
        grade[i]=np.mean(d[:,i])
    
    for i in range(band):
        if i%2==0:
            grade[i]=0

    sio.savemat(path+'grade.mat', {'grade':grade}) 

    select_matrix=np.zeros((band,selectnum),dtype=int)
    
    for i in range(selectnum):
        index=np.argmax(grade)
        select_matrix[index,i]=1
        grade[index]=-1
    #sio.savemat(path+'select_matrix.mat', {'select_matrix':select_matrix})    
    
    num=0
    for i in range(band):
        for j in range(selectnum):
            if select_matrix[i][j]==1:
                select_matrix[i][j]=0
                select_matrix[i][num]=1
                num=num+1
                print(i)
                break

    sio.savemat(path+'select_matrix.mat', {'select_matrix':select_matrix}) 

    return 0

def myinit_end(shape,dtype=None):

    data_t=sio.loadmat('superpixel_mat/'+str(patch)+'/kmeans_center.mat')['center']
    data=[] 
    for i in range(shape[0]):
        data.append([])
        for j in range(shape[1]):
            data[i].append((data_t[i][j]))
    
    data = tf.convert_to_tensor(data,dtype=float)
    print(type(data))
    return data

def myinit_select(shape,dtype=None):

    
    data_t=sio.loadmat('superpixel_mat/'+str(patch)+'/select_matrix.mat')['select_matrix']
    data=[] 
    for i in range(shape[0]):
        data.append([])
        for j in range(shape[1]):
            data[i].append((data_t[i][j]))   
    data = tf.convert_to_tensor(data,dtype=float)
    print(type(data))
    return data

def my_loss_sid(y_true,y_pred):
    x1=tf.divide(y_true,tf.reduce_sum(y_true,-1,keepdims=True))
    y1=tf.divide(y_pred,tf.reduce_sum(y_pred,-1,keepdims=True))
    x1=tf.clip_by_value(x1,0.0001,1)
    y1=tf.clip_by_value(y1,0.0001,1)
    data=tf.divide(y1,x1)
   # return tf.reduce_mean(tf.multiply(y1-x1,tf.log(data)),axis=-1)
    return tf.reduce_sum(tf.multiply(y1-x1,tf.log(data)))

def my_loss_sad(y_true,y_pred):

    yt_yp=tf.reduce_sum(y_true*y_pred,axis=-1)
    L2_yt=tf.sqrt(tf.reduce_sum(y_true*y_true,axis=-1))
    L2_yp=tf.sqrt(tf.reduce_sum(y_pred*y_pred,axis=-1))
    L2_yt_yp=L2_yt*L2_yp
    #return tf.reduce_mean(L2_yt_yp/yt_yp)
    return tf.reduce_mean(tf.acos(tf.clip_by_value(yt_yp/L2_yt_yp,-1,1)))

def my_loss_rmse(y_true,y_pred):

    squared_difference = tf.square(y_true - y_pred)
    return 0.001*tf.sqrt(tf.reduce_mean(tf.reduce_sum(squared_difference,axis=-1)))

def MyModel(input_tensor=None, input_shape=(5,5,100), classes=end_num, alpha=1.):


    if K.backend() != 'tensorflow':
        raise RuntimeError('The model is only available with '
                           'the TensorFlow backend.')

    if input_tensor is None:
        img_input = Input(shape=input_shape)
    else:
        if not K.is_keras_tensor(input_tensor):
            img_input = Input(tensor=input_tensor, shape=input_shape)
        else:
            img_input = input_tensor
    

    band=input_shape[2]
    
      
    select=Dense(selectnum,kernel_initializer=myinit_select,name='select',use_bias=False,trainable=False)(img_input)
    
    stage_1 = Conv2D(3*band, (3,3), strides=(1, 1),
                   name='s_stage_1',  padding='same')(select)

    stage_1_3 = Conv2D(3*band, (3,3), strides=(1, 1),
                   name='s_stage_1_3',  padding='same')(stage_1) 

    stage_1_1 = Conv2D(3*band, (1,1), strides=(1, 1),
                   name='s_stage_1_1',  padding='same')(stage_1)
    stage_1=Add()([stage_1_3,stage_1_1])
    
    stage_1=BatchNormalization(name='s_BN_stage_1',epsilon=1e-5)(stage_1)

    stage_1=Activation('relu',name='s_act1')(stage_1)
    

    
    stage_2 = Conv2D(2*band, (3,3), strides=(1, 1),
                   name='s_stage_2',  padding='same')(stage_1)
    
    stage_2_3 = Conv2D(2*band, (3,3), strides=(1, 1),
                   name='s_stage_2_3',  padding='same')(stage_2)  

    stage_2_1 = Conv2D(2*band, (1,1), strides=(1, 1),
                   name='s_stage_2_1', padding='same')(stage_2)

    stage_2=Add()([stage_2_3,stage_2_1])
    
    stage_2=BatchNormalization(name='s_BN_stage_2',epsilon=1e-5)(stage_2)

    stage_2=Activation('relu',name='s_act2')(stage_2)

    select_part = stage_2
    
    ################################################################################



    stage_1 = Conv2D(3*band, (3,3), strides=(1, 1),
                   name='a_stage_1',  padding='same')(img_input)

    stage_1_3 = Conv2D(3*band, (3,3), strides=(1, 1),
                   name='a_stage_1_3',  padding='same')(stage_1) 

    stage_1_1 = Conv2D(3*band, (1,1), strides=(1, 1),
                   name='a_stage_1_1',  padding='same')(stage_1)
    stage_1=Add()([stage_1_3,stage_1_1])
    
    stage_1=BatchNormalization(name='a_BN_stage_1',epsilon=1e-5)(stage_1)

    stage_1=Activation('relu',name='a_act1')(stage_1)
    

    stage_2 = Conv2D(2*band, (3,3), strides=(1, 1),
                   name='a_stage_2',  padding='same')(stage_1)
    
    stage_2_3 = Conv2D(2*band, (3,3), strides=(1, 1),
                   name='a_stage_2_3',  padding='same')(stage_2)  

    stage_2_1 = Conv2D(2*band, (1,1), strides=(1, 1),
                   name='a_stage_2_1', padding='same')(stage_2)


    stage_2=Add()([stage_2_3,stage_2_1])
    
    stage_2=BatchNormalization(name='a_BN_stage_2',epsilon=1e-5)(stage_2)

    stage_2=Activation('relu',name='a_act2')(stage_2)

    all_part = stage_2  
    ################################################################################

    last_encoder = Concatenate()([select_part,all_part])
      
    abundance=Dense(classes,name='abundance',activation='softmax')(last_encoder)

    b_p= Dense(int(classes*(classes-1)/2), name='bilinear_parameter',activation='relu')(abundance)


    linear_output=Dense(band,kernel_initializer=myinit_end,name='endmember',use_bias=False)(abundance)

    #bilinear_output=Dense(band,kernel_initializer=myinit_bilinear_end,name='b_endmember',use_bias=False)(b_p)
    bilinear_output=Dense(band,name='b_endmember',use_bias=False)(b_p)

    output=Add()([linear_output,bilinear_output])

    re_select=Dense(selectnum,kernel_initializer=myinit_select,name='reselect',use_bias=False,trainable=False)(linear_output)


    if input_tensor is not None:
        inputs = get_source_inputs(input_tensor)
    else:
        inputs = img_input

    model = Model(inputs, output, name='mymodel')  
      
    
    r1=1.0
    loss_sb_numerator=tf.reduce_sum(select*re_select,axis=-1)
    loss_sb_denominator=tf.sqrt(tf.reduce_sum(select*select,axis=-1))*tf.sqrt(tf.reduce_sum(re_select*re_select,axis=-1))
    ################################################################

   
    r2=1.0
    loss_lc_numerator=tf.reduce_sum(img_input*linear_output,axis=-1)
    loss_lc_denominator=tf.sqrt(tf.reduce_sum(img_input*img_input,axis=-1))*tf.sqrt(tf.reduce_sum(linear_output*linear_output,axis=-1))
    ################################################################

 
    model.add_loss(r1*tf.reduce_mean(tf.acos(tf.clip_by_value(loss_sb_numerator/loss_sb_denominator,-1,1)))+
                   r2*tf.reduce_mean(tf.acos(tf.clip_by_value(loss_lc_numerator/loss_lc_denominator,-1,1)))
    )

    return model

def generateData(all_data,img_w,img_h,stride,init=1):  
    
    train_data = []  
    train_label = []  
    path='ori_data'+str(img_w)+'-'+str(img_h)+'-'+str(stride)+'/'
    
    index = [i for i in range(all_data)]
    if init==0:
         
        temp = tf.random_shuffle(index,seed=-121)
        sess = tf.Session()
        sess.run(tf.global_variables_initializer())
        index=temp.eval(session=sess)
    

    for i in range (all_data):
        Data=sio.loadmat(path+str(index[i])+'.mat')
        tem_data=Data['data']

        for i1 in range(img_w):
            for j in range (img_h):
                for t in  range(band):
                    tem_data[i1,j,t]=tem_data[i1,j,t]

        train_data.append(tem_data)
    train_label=train_data
    
    train_data = np.array(train_data) 
    train_label = np.array(train_label)   
    
    return train_data ,train_label

def train(epochs,bs,path,all_data,img_w,img_h,stride):

     
    model=MyModel(input_shape=(img_w,img_h,band))
    with open(path+'model_summary.txt', 'w') as f:    
           with redirect_stdout(f):
                  model.summary(line_length=200,positions=[0.30,0.60,0.7,1.0])
 
    def lr_scheduler(epoch):
         lr_base = 0.0001
         lr_power = 0.9    
         lr = lr_base * ((1 - float(epoch)/epochs) ** lr_power)
         #print('lr: %f' % lr)
         print("lr changed to {}".format(lr))
         return lr
    
    lrate = LearningRateScheduler(lr_scheduler)
    
    adam = Adam(lr=0.0001, beta_1=0.9, beta_2=0.999, epsilon=1e-8)

    model.compile(loss=my_loss_rmse,optimizer ='adam',metrics=['mae'])
          
    checkpoint_save_path=path+'weights-result.h5'
 
    modelcheck = ModelCheckpoint(checkpoint_save_path,save_weights_only=True) 
    train_data,train_label=generateData(all_data,img_w,img_h,stride,init=0)
   
    H=model.fit(x=train_data,y=[train_label],batch_size=bs,epochs=epochs, verbose=2, callbacks=[modelcheck,lrate])
       
def predict(path,all_data,img_w,img_h,stride):

    model=MyModel(input_shape=(img_w,img_h,band))
    model.load_weights(path+'weights-result.h5',by_name=True)
    print(model.summary())
    abundance=Model(inputs=model.input,outputs=model.get_layer('abundance').output)
    bilinear_parameter=Model(inputs=model.input,outputs=model.get_layer('bilinear_parameter').output)
    #middle=Model(inputs=model.input,outputs=model.get_layer('abundance').output) 
    
    predict_endmember= model.get_layer('endmember').get_weights() 
    predict_endmember=np.array(predict_endmember)
    
    train_data,train_label=generateData(all_data,img_w,img_h,stride,init=1)
    flag=0
    
    for i in range(all_data):
        data=[]
        data.append(train_data[i,:,:,:])
        data=np.array(data)
        predict_reconstruction=model.predict(data,verbose=2)
       # predict_abundance=middle.predict(data,verbose=2)
        predict_abundance=abundance.predict(data,verbose=2)
        predict_bilinear_parameter=bilinear_parameter.predict(data,verbose=2)
        #print(type( predict_abundance1))
        #print(predict_reconstruction.shape)
    
        pre=[]
        for i2 in range(img_w):
            pre1=[]
            for i3 in range(img_h):
                pre2=[]
                for i4 in range(band):
                    pre2.append(predict_reconstruction[:,i2,i3,i4])
                pre1.append(pre2)
            pre.append(pre1)

        t_path=path+'predict_reconstruction/'
        if not os.path.exists(t_path):
            os.makedirs(t_path)
        sio.savemat(t_path+str(i)+'.mat', {'reconstruction':pre})
        
        pre=[]
        for i2 in range(img_w):
            pre1=[]
            for i3 in range(img_h):
                pre2=[]
                for i4 in range(end_num):
                    pre2.append(predict_abundance[:,i2,i3,i4])
                pre1.append(pre2)
            pre.append(pre1)

        t_path=path+'predict_abundance/'
        if not os.path.exists(t_path):
            os.makedirs(t_path)
        sio.savemat(t_path+str(i)+'.mat', {'abundance':pre})

        pre=[]
        for i2 in range(img_w):
            pre1=[]
            for i3 in range(img_h):
                pre2=[]
                for i4 in range(int(end_num*(end_num-1)/2)):
                    pre2.append(predict_bilinear_parameter[:,i2,i3,i4])
                pre1.append(pre2)
            pre.append(pre1)

        t_path=path+'predict_bilinear_parameter/'
        if not os.path.exists(t_path):
            os.makedirs(t_path)
        sio.savemat(t_path+str(i)+'.mat', {'bilinear_parameter':pre})
        
        
        if flag==0:
            pre=[]
            for i1 in range(end_num):
                pre1=[]
                for i2 in range(band):
                    pre1.append(predict_endmember[:,i1,i2])
                pre.append(pre1)
            t_path=path+'predict_endmember/'
            if not os.path.exists(t_path):
                os.makedirs(t_path)
            sio.savemat(t_path+str(i)+'.mat', {'endmember':pre})
            flag=1
        
        
    return 0


if __name__=='__main__':
    
  
    
    img_w=3   
    img_h=3   
    stride=3  
    all_data=dealData(img_w,img_h,stride) 
    Slic(patch)
    select_band(patch,selectnum)
    
    
    path='model/'
    if not os.path.exists(path):
        os.makedirs(path)

    epochs=30  
    bs=10  #10
    train(epochs,bs,path,all_data,img_w,img_h,stride)
    predict(path,all_data,img_w,img_h,stride)
    
    









    










  
